"use client"

import React, { useState } from "react"
import { Trophy, Star, Flame } from "lucide-react"

export function ProgressSystem() {
  const [level, setLevel] = useState(1)
  const [xp, setXp] = useState(30)
  const [streak, setStreak] = useState(3)
  const [medalhas, setMedalhas] = useState([
    { id: 1, nome: "Primeiro Dia", obtida: true },
    { id: 2, nome: "3 Dias Seguidos", obtida: true },
    { id: 3, nome: "Hidratação Perfeita", obtida: false },
    { id: 4, nome: "Mestre do Foco", obtida: false },
    { id: 5, nome: "Organização Total", obtida: false },
  ])
  
  const xpParaProximoNivel = 100
  const progresso = (xp / xpParaProximoNivel) * 100
  
  return (
    <div className="habit-card">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium flex items-center">
          <Trophy className="h-5 w-5 text-amber-500 mr-2" />
          Seu Progresso
        </h3>
        
        <div className="level-indicator">
          <span className="px-2 py-1 rounded-full bg-primary/10 text-primary">
            Nível {level}
          </span>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm">XP</span>
          <span className="text-sm text-muted-foreground">{xp}/{xpParaProximoNivel}</span>
        </div>
        <div className="progress-bar">
          <div 
            className="progress-bar-fill bg-primary" 
            style={{ width: `${progresso}%` }}
          ></div>
        </div>
      </div>
      
      <div className="flex items-center mb-4">
        <div className="streak-counter">
          <Flame className="h-4 w-4 text-amber-500" />
          <span>{streak} dias seguidos</span>
        </div>
      </div>
      
      <div>
        <h4 className="text-sm font-medium mb-2">Suas Medalhas</h4>
        <div className="grid grid-cols-2 gap-2">
          {medalhas.map(medalha => (
            <div 
              key={medalha.id}
              className={`p-2 rounded-md text-xs flex items-center ${
                medalha.obtida 
                  ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300" 
                  : "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
              }`}
            >
              <Star className={`h-3 w-3 mr-1 ${medalha.obtida ? "text-amber-500" : "text-gray-400"}`} />
              {medalha.nome}
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-muted-foreground">
          Continue assim! Você está no caminho certo.
        </p>
      </div>
    </div>
  )
}
