"use client"

import React, { useState, useEffect } from "react"
import { Play, Pause, RotateCcw } from "lucide-react"

export function PomodoroTimer() {
  const [minutes, setMinutes] = useState(25)
  const [seconds, setSeconds] = useState(0)
  const [isActive, setIsActive] = useState(false)
  const [mode, setMode] = useState<"focus" | "break">("focus")
  
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null
    
    if (isActive) {
      interval = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            // Timer completed
            clearInterval(interval as NodeJS.Timeout)
            setIsActive(false)
            
            // Switch modes
            if (mode === "focus") {
              setMode("break")
              setMinutes(5)
              setSeconds(0)
              // Optionally play sound or show notification
            } else {
              setMode("focus")
              setMinutes(25)
              setSeconds(0)
            }
            
            return
          }
          
          setMinutes(minutes - 1)
          setSeconds(59)
        } else {
          setSeconds(seconds - 1)
        }
      }, 1000)
    } else if (interval) {
      clearInterval(interval)
    }
    
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, minutes, seconds, mode])
  
  const toggleTimer = () => {
    setIsActive(!isActive)
  }
  
  const resetTimer = () => {
    setIsActive(false)
    if (mode === "focus") {
      setMinutes(25)
    } else {
      setMinutes(5)
    }
    setSeconds(0)
  }
  
  return (
    <div className="p-6 rounded-lg border border-border bg-card shadow-md">
      <h3 className="text-lg font-medium mb-4 text-center">
        {mode === "focus" ? "Tempo de Foco" : "Pausa"}
      </h3>
      
      <div className="pomodoro-timer">
        {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
      </div>
      
      <div className="flex justify-center space-x-4 mt-4">
        <button
          onClick={toggleTimer}
          className="p-2 rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
          aria-label={isActive ? "Pausar" : "Iniciar"}
        >
          {isActive ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
        </button>
        
        <button
          onClick={resetTimer}
          className="p-2 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
          aria-label="Reiniciar"
        >
          <RotateCcw className="h-5 w-5" />
        </button>
      </div>
      
      <div className="mt-4 text-center text-sm text-muted-foreground">
        {mode === "focus" 
          ? "Concentre-se na sua tarefa atual" 
          : "Faça uma pausa, estique-se, beba água"}
      </div>
    </div>
  )
}
