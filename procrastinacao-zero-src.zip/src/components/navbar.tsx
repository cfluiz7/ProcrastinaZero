"use client"

import React from "react"
import Link from "next/link"
import { ThemeToggle } from "./theme-toggle"
import { Home, Calendar, BarChart, Award, Settings } from "lucide-react"

export function Navbar() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-2 md:top-0 md:bottom-auto md:border-t-0 md:border-b z-50">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-primary hidden md:block">
          Procrastinação Zero
        </Link>
        
        <div className="flex items-center justify-around w-full md:w-auto md:space-x-6">
          <NavItem href="/" icon={<Home className="h-5 w-5" />} label="Início" />
          <NavItem href="/cronograma" icon={<Calendar className="h-5 w-5" />} label="Cronograma" />
          <NavItem href="/habitos" icon={<BarChart className="h-5 w-5" />} label="Hábitos" />
          <NavItem href="/progresso" icon={<Award className="h-5 w-5" />} label="Progresso" />
          <NavItem href="/configuracoes" icon={<Settings className="h-5 w-5" />} label="Config" />
        </div>
        
        <div className="hidden md:block">
          <ThemeToggle />
        </div>
      </div>
    </nav>
  )
}

function NavItem({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link 
      href={href} 
      className="flex flex-col items-center justify-center p-2 text-muted-foreground hover:text-foreground transition-colors"
    >
      {icon}
      <span className="text-xs mt-1">{label}</span>
    </Link>
  )
}
