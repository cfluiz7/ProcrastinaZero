"use client"

import React, { useState } from "react"
import { Droplet, AlertCircle } from "lucide-react"

export function HabitTracker() {
  const [agua, setAgua] = useState(0)
  const [refeicoes, setRefeicoes] = useState(0)
  
  return (
    <div className="habit-card">
      <h3 className="text-lg font-medium mb-4">Monitoramento Diário</h3>
      
      <div className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium flex items-center">
              <Droplet className="h-4 w-4 text-blue-500 mr-1" />
              Hidratação
            </span>
            <span className="text-sm text-muted-foreground">{agua}/8 copos</span>
          </div>
          <div className="progress-bar">
            <div 
              className="progress-bar-fill bg-blue-500" 
              style={{ width: `${Math.min(100, (agua / 8) * 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-2">
            <button 
              onClick={() => setAgua(Math.max(0, agua - 1))}
              className="text-xs px-2 py-1 rounded bg-secondary text-secondary-foreground"
              disabled={agua <= 0}
            >
              -
            </button>
            <button 
              onClick={() => setAgua(Math.min(8, agua + 1))}
              className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground"
            >
              + Copo
            </button>
          </div>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Refeições Saudáveis</span>
            <span className="text-sm text-muted-foreground">{refeicoes}/5 refeições</span>
          </div>
          <div className="progress-bar">
            <div 
              className="progress-bar-fill bg-green-500" 
              style={{ width: `${Math.min(100, (refeicoes / 5) * 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-2">
            <button 
              onClick={() => setRefeicoes(Math.max(0, refeicoes - 1))}
              className="text-xs px-2 py-1 rounded bg-secondary text-secondary-foreground"
              disabled={refeicoes <= 0}
            >
              -
            </button>
            <button 
              onClick={() => setRefeicoes(Math.min(5, refeicoes + 1))}
              className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground"
            >
              + Refeição
            </button>
          </div>
        </div>
      </div>
      
      {agua < 3 && (
        <div className="mt-4 p-2 bg-amber-50 dark:bg-amber-900/30 rounded-md flex items-center">
          <AlertCircle className="h-4 w-4 text-amber-500 mr-2" />
          <span className="text-xs text-amber-700 dark:text-amber-300">
            Você está bebendo pouca água hoje!
          </span>
        </div>
      )}
    </div>
  )
}
