"use client"

import React, { createContext, useContext, useState, useEffect } from "react"

// Tipos para o contexto
type Usuario = {
  nome: string;
  nivel: number;
  xp: number;
  streak: number;
  conquistas: number[];
}

type HabitosRegistro = {
  data: string;
  agua: number;
  refeicoes: number;
  sono: number;
  estudos: number;
}

type Tarefa = {
  id: string;
  materiaId: string;
  descricao: string;
  concluida: boolean;
  duracao: number;
}

type AppState = {
  usuario: Usuario;
  habitos: HabitosRegistro[];
  tarefas: Tarefa[];
  configuracoes: {
    tema: "light" | "dark" | "system";
    notificacoes: boolean;
    sons: boolean;
    horasDormir: string;
    horasAcordar: string;
    metas: {
      agua: number;
      refeicoes: number;
      estudos: number;
      sono: number;
    }
  }
}

type AppContextType = {
  state: AppState;
  atualizarUsuario: (dados: Partial<Usuario>) => void;
  registrarHabito: (registro: Partial<HabitosRegistro>) => void;
  adicionarTarefa: (tarefa: Omit<Tarefa, "id">) => void;
  atualizarTarefa: (id: string, dados: Partial<Tarefa>) => void;
  removerTarefa: (id: string) => void;
  atualizarConfiguracoes: (config: Partial<AppState["configuracoes"]>) => void;
  ganharXP: (quantidade: number) => void;
  conquistarMedalha: (id: number) => void;
}

// Estado inicial
const estadoInicial: AppState = {
  usuario: {
    nome: "Estudante",
    nivel: 1,
    xp: 30,
    streak: 3,
    conquistas: [1, 2]
  },
  habitos: [
    { 
      data: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      agua: 5, 
      refeicoes: 3, 
      sono: 6, 
      estudos: 2 
    },
    { 
      data: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      agua: 6, 
      refeicoes: 4, 
      sono: 7, 
      estudos: 3 
    },
    { 
      data: new Date().toISOString().split('T')[0], 
      agua: 2, 
      refeicoes: 1, 
      sono: 0, 
      estudos: 1 
    }
  ],
  tarefas: [
    { id: "t1", materiaId: "mat1", descricao: "Resolver exercícios de álgebra", concluida: false, duracao: 25 },
    { id: "t2", materiaId: "port1", descricao: "Ler capítulo sobre sintaxe", concluida: false, duracao: 25 },
    { id: "t3", materiaId: "hist1", descricao: "Resumir texto sobre Brasil Colônia", concluida: false, duracao: 25 },
  ],
  configuracoes: {
    tema: "system",
    notificacoes: true,
    sons: true,
    horasDormir: "22:30",
    horasAcordar: "07:00",
    metas: {
      agua: 8,
      refeicoes: 5,
      estudos: 4,
      sono: 8
    }
  }
}

// Níveis de experiência
const niveis = [
  { nivel: 1, xpNecessario: 0 },
  { nivel: 2, xpNecessario: 100 },
  { nivel: 3, xpNecessario: 250 },
  { nivel: 4, xpNecessario: 500 },
  { nivel: 5, xpNecessario: 1000 }
]

// Criar o contexto
const AppContext = createContext<AppContextType | undefined>(undefined)

// Hook para usar o contexto
export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext deve ser usado dentro de um AppProvider")
  }
  return context
}

// Provedor do contexto
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(estadoInicial)
  
  // Carregar dados do localStorage ao iniciar
  useEffect(() => {
    const dadosSalvos = localStorage.getItem("procrastinacaoZeroData")
    if (dadosSalvos) {
      try {
        const dados = JSON.parse(dadosSalvos)
        setState(dados)
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
      }
    }
  }, [])
  
  // Salvar dados no localStorage quando o estado mudar
  useEffect(() => {
    localStorage.setItem("procrastinacaoZeroData", JSON.stringify(state))
  }, [state])
  
  // Atualizar dados do usuário
  const atualizarUsuario = (dados: Partial<Usuario>) => {
    setState(prev => ({
      ...prev,
      usuario: {
        ...prev.usuario,
        ...dados
      }
    }))
  }
  
  // Registrar hábitos
  const registrarHabito = (registro: Partial<HabitosRegistro>) => {
    const hoje = new Date().toISOString().split('T')[0]
    const data = registro.data || hoje
    
    setState(prev => {
      const habitosAtualizados = [...prev.habitos]
      const indiceExistente = habitosAtualizados.findIndex(h => h.data === data)
      
      if (indiceExistente >= 0) {
        // Atualizar registro existente
        habitosAtualizados[indiceExistente] = {
          ...habitosAtualizados[indiceExistente],
          ...registro
        }
      } else {
        // Criar novo registro
        habitosAtualizados.push({
          data,
          agua: registro.agua || 0,
          refeicoes: registro.refeicoes || 0,
          sono: registro.sono || 0,
          estudos: registro.estudos || 0
        })
      }
      
      return {
        ...prev,
        habitos: habitosAtualizados
      }
    })
  }
  
  // Adicionar tarefa
  const adicionarTarefa = (tarefa: Omit<Tarefa, "id">) => {
    const novaTarefa: Tarefa = {
      ...tarefa,
      id: `t${Date.now()}`
    }
    
    setState(prev => ({
      ...prev,
      tarefas: [...prev.tarefas, novaTarefa]
    }))
  }
  
  // Atualizar tarefa
  const atualizarTarefa = (id: string, dados: Partial<Tarefa>) => {
    setState(prev => ({
      ...prev,
      tarefas: prev.tarefas.map(tarefa => 
        tarefa.id === id ? { ...tarefa, ...dados } : tarefa
      )
    }))
    
    // Se a tarefa foi concluída, ganhar XP
    if (dados.concluida === true) {
      ganharXP(10)
    }
  }
  
  // Remover tarefa
  const removerTarefa = (id: string) => {
    setState(prev => ({
      ...prev,
      tarefas: prev.tarefas.filter(tarefa => tarefa.id !== id)
    }))
  }
  
  // Atualizar configurações
  const atualizarConfiguracoes = (config: Partial<AppState["configuracoes"]>) => {
    setState(prev => ({
      ...prev,
      configuracoes: {
        ...prev.configuracoes,
        ...config,
        metas: {
          ...prev.configuracoes.metas,
          ...(config.metas || {})
        }
      }
    }))
  }
  
  // Ganhar XP e subir de nível se necessário
  const ganharXP = (quantidade: number) => {
    setState(prev => {
      const novoXP = prev.usuario.xp + quantidade
      let novoNivel = prev.usuario.nivel
      
      // Verificar se subiu de nível
      for (const nivel of niveis) {
        if (novoXP >= nivel.xpNecessario && nivel.nivel > novoNivel) {
          novoNivel = nivel.nivel
        }
      }
      
      return {
        ...prev,
        usuario: {
          ...prev.usuario,
          xp: novoXP,
          nivel: novoNivel
        }
      }
    })
  }
  
  // Conquistar medalha
  const conquistarMedalha = (id: number) => {
    setState(prev => {
      // Verificar se já tem a medalha
      if (prev.usuario.conquistas.includes(id)) {
        return prev
      }
      
      // Adicionar medalha e ganhar XP
      return {
        ...prev,
        usuario: {
          ...prev.usuario,
          conquistas: [...prev.usuario.conquistas, id],
          xp: prev.usuario.xp + 25
        }
      }
    })
  }
  
  const contextValue: AppContextType = {
    state,
    atualizarUsuario,
    registrarHabito,
    adicionarTarefa,
    atualizarTarefa,
    removerTarefa,
    atualizarConfiguracoes,
    ganharXP,
    conquistarMedalha
  }
  
  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  )
}
