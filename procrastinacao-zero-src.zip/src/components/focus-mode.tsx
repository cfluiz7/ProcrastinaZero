"use client"

import React, { useState } from "react"
import { Clock, BellRing, X } from "lucide-react"

export function FocusMode() {
  const [isActive, setIsActive] = useState(false)
  const [focusTime, setFocusTime] = useState(25)
  
  const activateFocusMode = () => {
    setIsActive(true)
  }
  
  const deactivateFocusMode = () => {
    setIsActive(false)
  }
  
  return (
    <>
      <div className="habit-card">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Clock className="h-5 w-5 text-primary mr-2" />
          Modo Foco
        </h3>
        
        <p className="text-sm text-muted-foreground mb-4">
          Ative o modo foco para bloquear distrações e concentrar-se nos estudos.
        </p>
        
        <div className="mb-4">
          <label htmlFor="focus-time" className="block text-sm font-medium mb-1">
            Tempo de foco (minutos)
          </label>
          <input
            type="range"
            id="focus-time"
            min="5"
            max="60"
            step="5"
            value={focusTime}
            onChange={(e) => setFocusTime(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>5 min</span>
            <span>{focusTime} min</span>
            <span>60 min</span>
          </div>
        </div>
        
        <div className="flex justify-center">
          <button
            onClick={activateFocusMode}
            className="px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Ativar Modo Foco
          </button>
        </div>
      </div>
      
      {isActive && (
        <div className="focus-mode">
          <div className="absolute top-4 right-4">
            <button
              onClick={deactivateFocusMode}
              className="p-2 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              aria-label="Sair do modo foco"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-2">Modo Foco Ativado</h2>
            <p className="text-xl mb-8">Concentre-se na sua tarefa</p>
            
            <div className="pomodoro-timer mb-8">
              {focusTime}:00
            </div>
            
            <div className="max-w-md mx-auto p-4 bg-card rounded-lg border border-border">
              <h3 className="text-lg font-medium mb-2">Dicas para manter o foco:</h3>
              <ul className="text-sm text-left space-y-2">
                <li>• Respire fundo e mantenha a calma</li>
                <li>• Foque em uma tarefa por vez</li>
                <li>• Elimine distrações do ambiente</li>
                <li>• Beba água regularmente</li>
                <li>• Faça pequenas pausas quando necessário</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
