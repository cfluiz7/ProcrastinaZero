"use client"

import React from "react"
import { Navbar } from "@/components/navbar"

export default function MainLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto p-4 pt-6 md:pt-20 pb-24 md:pb-6">
        {children}
      </main>
    </div>
  )
}
