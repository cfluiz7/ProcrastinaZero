"use client"

import React, { useState } from "react"
import { Clock, Coffee, Sun, Moon, Droplet } from "lucide-react"

export function RitualCard({ tipo }: { tipo: "matinal" | "noturno" }) {
  const [checklist, setChecklist] = useState<Record<string, boolean>>({})
  
  const itensMatinais = [
    { id: "agua", label: "Beber um copo d'água" },
    { id: "alimentacao", label: "Comer algo saudável" },
    { id: "missao", label: "Definir a missão do dia" },
  ]
  
  const itensNoturnos = [
    { id: "preparacao", label: "Preparar material para amanhã" },
    { id: "reflexao", label: "Refletir sobre o dia" },
    { id: "dormir", label: "Definir hora de dormir" },
  ]
  
  const itens = tipo === "matinal" ? itensMatinais : itensNoturnos
  
  const toggleItem = (id: string) => {
    setChecklist(prev => ({
      ...prev,
      [id]: !prev[id]
    }))
  }
  
  return (
    <div className="habit-card">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium">
          {tipo === "matinal" ? (
            <span className="flex items-center">
              <Sun className="mr-2 h-5 w-5 text-amber-500" />
              Ritual Matinal
            </span>
          ) : (
            <span className="flex items-center">
              <Moon className="mr-2 h-5 w-5 text-indigo-400" />
              Ritual Noturno
            </span>
          )}
        </h3>
        <span className="text-sm text-muted-foreground">
          {new Date().toLocaleDateString('pt-BR')}
        </span>
      </div>
      
      <div className="space-y-2">
        {itens.map(item => (
          <div key={item.id} className="checklist-item">
            <input
              type="checkbox"
              id={item.id}
              checked={!!checklist[item.id]}
              onChange={() => toggleItem(item.id)}
              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
            />
            <label htmlFor={item.id} className="ml-2 text-sm font-medium">
              {item.label}
            </label>
          </div>
        ))}
      </div>
      
      {tipo === "matinal" && (
        <div className="mt-4 p-2 bg-blue-50 dark:bg-blue-900/30 rounded-md flex items-center">
          <Droplet className="h-4 w-4 text-blue-500 mr-2" />
          <span className="text-xs text-blue-700 dark:text-blue-300">
            Lembre-se de beber água durante o dia!
          </span>
        </div>
      )}
      
      {tipo === "noturno" && (
        <div className="mt-4 p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-md flex items-center">
          <Clock className="h-4 w-4 text-indigo-500 mr-2" />
          <span className="text-xs text-indigo-700 dark:text-indigo-300">
            Dormir cedo ajuda na recuperação do corpo e mente!
          </span>
        </div>
      )}
    </div>
  )
}
