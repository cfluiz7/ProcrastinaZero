"use client"

import React, { useState, useEffect } from "react"
import { MainLayout } from "@/components/main-layout"
import { Settings, Moon, Sun, Bell, Volume2, VolumeX, Save, RotateCcw } from "lucide-react"

export default function Configuracoes() {
  const [tema, setTema] = useState<"light" | "dark" | "system">("system")
  const [notificacoes, setNotificacoes] = useState(true)
  const [sons, setSons] = useState(true)
  const [horasDormir, setHorasDormir] = useState("22:30")
  const [horasAcordar, setHorasAcordar] = useState("07:00")
  const [metaDiaria, setMetaDiaria] = useState({
    agua: 8,
    refeicoes: 5,
    estudos: 4,
    sono: 8
  })
  
  const [salvando, setSalvando] = useState(false)
  const [mensagem, setMensagem] = useState<{texto: string, tipo: "sucesso" | "erro"} | null>(null)
  
  const salvarConfiguracoes = () => {
    setSalvando(true)
    
    // Simulação de salvamento
    setTimeout(() => {
      setSalvando(false)
      setMensagem({
        texto: "Configurações salvas com sucesso!",
        tipo: "sucesso"
      })
      
      // Limpar mensagem após 3 segundos
      setTimeout(() => {
        setMensagem(null)
      }, 3000)
    }, 1000)
  }
  
  const resetarConfiguracoes = () => {
    setTema("system")
    setNotificacoes(true)
    setSons(true)
    setHorasDormir("22:30")
    setHorasAcordar("07:00")
    setMetaDiaria({
      agua: 8,
      refeicoes: 5,
      estudos: 4,
      sono: 8
    })
    
    setMensagem({
      texto: "Configurações resetadas para os valores padrão",
      tipo: "sucesso"
    })
    
    // Limpar mensagem após 3 segundos
    setTimeout(() => {
      setMensagem(null)
    }, 3000)
  }
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 flex items-center">
          <Settings className="h-6 w-6 mr-2" />
          Configurações
        </h1>
        
        {mensagem && (
          <div className={`mb-6 p-4 rounded-md ${
            mensagem.tipo === "sucesso" 
              ? "bg-green-50 text-green-800 dark:bg-green-900/30 dark:text-green-200" 
              : "bg-red-50 text-red-800 dark:bg-red-900/30 dark:text-red-200"
          }`}>
            {mensagem.texto}
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4">Aparência</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Tema</label>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setTema("light")}
                    className={`flex-1 py-2 px-3 rounded-md flex items-center justify-center ${
                      tema === "light" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    <Sun className="h-4 w-4 mr-2" />
                    Claro
                  </button>
                  
                  <button
                    onClick={() => setTema("dark")}
                    className={`flex-1 py-2 px-3 rounded-md flex items-center justify-center ${
                      tema === "dark" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    <Moon className="h-4 w-4 mr-2" />
                    Escuro
                  </button>
                  
                  <button
                    onClick={() => setTema("system")}
                    className={`flex-1 py-2 px-3 rounded-md flex items-center justify-center ${
                      tema === "system" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    Sistema
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4">Notificações</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Bell className="h-5 w-5 mr-2 text-primary" />
                  <span>Lembretes e alertas</span>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={notificacoes} 
                    onChange={() => setNotificacoes(!notificacoes)} 
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {sons ? (
                    <Volume2 className="h-5 w-5 mr-2 text-primary" />
                  ) : (
                    <VolumeX className="h-5 w-5 mr-2 text-primary" />
                  )}
                  <span>Sons de notificação</span>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={sons} 
                    onChange={() => setSons(!sons)} 
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                </label>
              </div>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4">Rotina de Sono</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="hora-dormir" className="block text-sm font-medium mb-2">
                  Horário para dormir
                </label>
                <input
                  type="time"
                  id="hora-dormir"
                  value={horasDormir}
                  onChange={(e) => setHorasDormir(e.target.value)}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <div>
                <label htmlFor="hora-acordar" className="block text-sm font-medium mb-2">
                  Horário para acordar
                </label>
                <input
                  type="time"
                  id="hora-acordar"
                  value={horasAcordar}
                  onChange={(e) => setHorasAcordar(e.target.value)}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <div className="p-3 rounded-md bg-blue-50 dark:bg-blue-900/30 text-sm">
                <p className="text-blue-700 dark:text-blue-300">
                  Tempo de sono recomendado: 7-9 horas por noite
                </p>
              </div>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4">Metas Diárias</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="meta-agua" className="block text-sm font-medium mb-2">
                  Copos de água
                </label>
                <input
                  type="number"
                  id="meta-agua"
                  min="1"
                  max="12"
                  value={metaDiaria.agua}
                  onChange={(e) => setMetaDiaria({...metaDiaria, agua: parseInt(e.target.value)})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <div>
                <label htmlFor="meta-refeicoes" className="block text-sm font-medium mb-2">
                  Refeições saudáveis
                </label>
                <input
                  type="number"
                  id="meta-refeicoes"
                  min="1"
                  max="6"
                  value={metaDiaria.refeicoes}
                  onChange={(e) => setMetaDiaria({...metaDiaria, refeicoes: parseInt(e.target.value)})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <div>
                <label htmlFor="meta-estudos" className="block text-sm font-medium mb-2">
                  Horas de estudo
                </label>
                <input
                  type="number"
                  id="meta-estudos"
                  min="1"
                  max="10"
                  value={metaDiaria.estudos}
                  onChange={(e) => setMetaDiaria({...metaDiaria, estudos: parseInt(e.target.value)})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <div>
                <label htmlFor="meta-sono" className="block text-sm font-medium mb-2">
                  Horas de sono
                </label>
                <input
                  type="number"
                  id="meta-sono"
                  min="5"
                  max="12"
                  value={metaDiaria.sono}
                  onChange={(e) => setMetaDiaria({...metaDiaria, sono: parseInt(e.target.value)})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between mt-8">
          <button
            onClick={resetarConfiguracoes}
            className="py-2 px-4 rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/80 flex items-center"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Resetar
          </button>
          
          <button
            onClick={salvarConfiguracoes}
            disabled={salvando}
            className="py-2 px-4 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 flex items-center"
          >
            <Save className="h-4 w-4 mr-2" />
            {salvando ? "Salvando..." : "Salvar Configurações"}
          </button>
        </div>
      </div>
    </MainLayout>
  )
}
