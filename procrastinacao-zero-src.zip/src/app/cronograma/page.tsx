"use client"

import React, { useState } from "react"
import { MainLayout } from "@/components/main-layout"
import { PomodoroTimer } from "@/components/pomodoro-timer"
import { Calendar, Clock, BookOpen, ListTodo } from "lucide-react"

type Materia = {
  id: string
  nome: string
  prioridade: "alta" | "media" | "baixa"
  topicos: string[]
}

type Tarefa = {
  id: string
  materiaId: string
  descricao: string
  concluida: boolean
  duracao: number // em minutos
}

export default function Cronograma() {
  const [materias, setMaterias] = useState<Materia[]>([
    { id: "mat1", nome: "Matemática", prioridade: "alta", topicos: ["Álgebra", "Geometria", "Estatística"] },
    { id: "port1", nome: "Português", prioridade: "media", topicos: ["Gramática", "Interpretação", "Redação"] },
    { id: "hist1", nome: "História", prioridade: "baixa", topicos: ["Brasil Colônia", "Idade Média", "Revolução Industrial"] },
  ])
  
  const [tarefas, setTarefas] = useState<Tarefa[]>([
    { id: "t1", materiaId: "mat1", descricao: "Resolver exercícios de álgebra", concluida: false, duracao: 25 },
    { id: "t2", materiaId: "port1", descricao: "Ler capítulo sobre sintaxe", concluida: false, duracao: 25 },
    { id: "t3", materiaId: "hist1", descricao: "Resumir texto sobre Brasil Colônia", concluida: false, duracao: 25 },
  ])
  
  const [novaTarefa, setNovaTarefa] = useState({
    materiaId: "",
    descricao: "",
    duracao: 25
  })
  
  const [novaMateria, setNovaMateria] = useState({
    nome: "",
    prioridade: "media" as "alta" | "media" | "baixa",
    topicos: ""
  })
  
  const adicionarTarefa = () => {
    if (novaTarefa.descricao.trim() === "" || novaTarefa.materiaId === "") return
    
    const novaTarefaObj: Tarefa = {
      id: `t${Date.now()}`,
      materiaId: novaTarefa.materiaId,
      descricao: novaTarefa.descricao,
      concluida: false,
      duracao: novaTarefa.duracao
    }
    
    setTarefas([...tarefas, novaTarefaObj])
    setNovaTarefa({
      materiaId: "",
      descricao: "",
      duracao: 25
    })
  }
  
  const adicionarMateria = () => {
    if (novaMateria.nome.trim() === "") return
    
    const novaMatObj: Materia = {
      id: `m${Date.now()}`,
      nome: novaMateria.nome,
      prioridade: novaMateria.prioridade,
      topicos: novaMateria.topicos.split(",").map(t => t.trim()).filter(t => t !== "")
    }
    
    setMaterias([...materias, novaMatObj])
    setNovaMateria({
      nome: "",
      prioridade: "media",
      topicos: ""
    })
  }
  
  const toggleTarefaConcluida = (id: string) => {
    setTarefas(tarefas.map(tarefa => 
      tarefa.id === id ? { ...tarefa, concluida: !tarefa.concluida } : tarefa
    ))
  }
  
  const getPrioridadeClasse = (prioridade: string) => {
    switch (prioridade) {
      case "alta": return "badge-danger"
      case "media": return "badge-warning"
      case "baixa": return "badge-success"
      default: return ""
    }
  }
  
  const getPrioridadeTexto = (prioridade: string) => {
    switch (prioridade) {
      case "alta": return "Alta"
      case "media": return "Média"
      case "baixa": return "Baixa"
      default: return ""
    }
  }
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Cronograma de Estudos</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Clock className="h-5 w-5 text-primary mr-2" />
              Pomodoro
            </h2>
            <PomodoroTimer />
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Calendar className="h-5 w-5 text-primary mr-2" />
              Adicionar Tarefa
            </h2>
            
            <div className="space-y-3">
              <div>
                <label htmlFor="materia" className="block text-sm font-medium mb-1">
                  Matéria
                </label>
                <select
                  id="materia"
                  value={novaTarefa.materiaId}
                  onChange={(e) => setNovaTarefa({...novaTarefa, materiaId: e.target.value})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                >
                  <option value="">Selecione uma matéria</option>
                  {materias.map(materia => (
                    <option key={materia.id} value={materia.id}>{materia.nome}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="descricao" className="block text-sm font-medium mb-1">
                  Descrição
                </label>
                <input
                  type="text"
                  id="descricao"
                  value={novaTarefa.descricao}
                  onChange={(e) => setNovaTarefa({...novaTarefa, descricao: e.target.value})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                  placeholder="O que você precisa estudar?"
                />
              </div>
              
              <div>
                <label htmlFor="duracao" className="block text-sm font-medium mb-1">
                  Duração (minutos)
                </label>
                <input
                  type="number"
                  id="duracao"
                  min="5"
                  step="5"
                  value={novaTarefa.duracao}
                  onChange={(e) => setNovaTarefa({...novaTarefa, duracao: parseInt(e.target.value)})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                />
              </div>
              
              <button
                onClick={adicionarTarefa}
                className="w-full py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Adicionar Tarefa
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <BookOpen className="h-5 w-5 text-primary mr-2" />
              Suas Matérias
            </h2>
            
            <div className="space-y-4 mb-4">
              {materias.map(materia => (
                <div key={materia.id} className="p-3 rounded-md bg-card border border-border">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">{materia.nome}</h3>
                    <span className={`badge ${getPrioridadeClasse(materia.prioridade)}`}>
                      {getPrioridadeTexto(materia.prioridade)}
                    </span>
                  </div>
                  
                  {materia.topicos.length > 0 && (
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium">Tópicos: </span>
                      {materia.topicos.join(", ")}
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <div className="space-y-3">
              <div>
                <label htmlFor="nome-materia" className="block text-sm font-medium mb-1">
                  Nome da Matéria
                </label>
                <input
                  type="text"
                  id="nome-materia"
                  value={novaMateria.nome}
                  onChange={(e) => setNovaMateria({...novaMateria, nome: e.target.value})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                  placeholder="Ex: Física"
                />
              </div>
              
              <div>
                <label htmlFor="prioridade" className="block text-sm font-medium mb-1">
                  Prioridade
                </label>
                <select
                  id="prioridade"
                  value={novaMateria.prioridade}
                  onChange={(e) => setNovaMateria({...novaMateria, prioridade: e.target.value as "alta" | "media" | "baixa"})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                >
                  <option value="alta">Alta</option>
                  <option value="media">Média</option>
                  <option value="baixa">Baixa</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="topicos" className="block text-sm font-medium mb-1">
                  Tópicos (separados por vírgula)
                </label>
                <input
                  type="text"
                  id="topicos"
                  value={novaMateria.topicos}
                  onChange={(e) => setNovaMateria({...novaMateria, topicos: e.target.value})}
                  className="w-full p-2 rounded-md border border-input bg-background"
                  placeholder="Ex: Mecânica, Óptica, Termodinâmica"
                />
              </div>
              
              <button
                onClick={adicionarMateria}
                className="w-full py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Adicionar Matéria
              </button>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <ListTodo className="h-5 w-5 text-primary mr-2" />
              Tarefas de Hoje
            </h2>
            
            <div className="space-y-2">
              {tarefas.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">
                  Nenhuma tarefa adicionada ainda.
                </p>
              ) : (
                tarefas.map(tarefa => {
                  const materia = materias.find(m => m.id === tarefa.materiaId)
                  
                  return (
                    <div 
                      key={tarefa.id} 
                      className={`p-3 rounded-md border ${
                        tarefa.concluida 
                          ? "bg-muted border-muted" 
                          : "bg-card border-border"
                      }`}
                    >
                      <div className="flex items-start">
                        <input
                          type="checkbox"
                          checked={tarefa.concluida}
                          onChange={() => toggleTarefaConcluida(tarefa.id)}
                          className="mt-1 h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <div className="ml-3 flex-1">
                          <p className={tarefa.concluida ? "line-through text-muted-foreground" : ""}>
                            {tarefa.descricao}
                          </p>
                          <div className="flex justify-between text-xs text-muted-foreground mt-1">
                            <span>{materia?.nome}</span>
                            <span>{tarefa.duracao} min</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
