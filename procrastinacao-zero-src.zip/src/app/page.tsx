"use client"

import React, { useEffect } from "react"
import { useAppContext } from "@/components/app-provider"
import { MainLayout } from "@/components/main-layout"
import { RitualCard } from "@/components/ritual-card"
import { PomodoroTimer } from "@/components/pomodoro-timer"
import { HabitTracker } from "@/components/habit-tracker"
import { ProgressSystem } from "@/components/progress-system"
import { FocusMode } from "@/components/focus-mode"
import { Droplet } from "lucide-react"

export default function Home() {
  const { state, ganharXP } = useAppContext()
  const [showWaterReminder, setShowWaterReminder] = React.useState(false)
  
  // Simulação de lembretes de água a cada hora
  useEffect(() => {
    const interval = setInterval(() => {
      setShowWaterReminder(true)
      
      // Esconder o lembrete após 10 segundos
      setTimeout(() => {
        setShowWaterReminder(false)
      }, 10000)
    }, 60 * 60 * 1000) // A cada hora
    
    // Para demonstração, mostrar o lembrete após 30 segundos
    const initialTimeout = setTimeout(() => {
      setShowWaterReminder(true)
      
      setTimeout(() => {
        setShowWaterReminder(false)
      }, 10000)
    }, 30000)
    
    return () => {
      clearInterval(interval)
      clearTimeout(initialTimeout)
    }
  }, [])
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <section className="mb-8">
          <div className="motivation-card mb-6">
            <h1 className="text-2xl font-bold mb-2">Bem-vindo ao Procrastinação Zero</h1>
            <p className="text-muted-foreground">
              Sua plataforma completa para recuperar seus estudos e vencer a procrastinação.
              Comece hoje mesmo a transformar seus hábitos!
            </p>
            <div className="mt-2 text-sm">
              <span className="font-medium">Nível {state.usuario.nivel}</span>
              <span className="text-muted-foreground ml-2">{state.usuario.xp} XP</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <RitualCard tipo="matinal" />
            <RitualCard tipo="noturno" />
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Foco nos Estudos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <PomodoroTimer />
            <FocusMode />
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Seus Hábitos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <HabitTracker />
            <ProgressSystem />
          </div>
        </section>
      </div>
      
      {showWaterReminder && (
        <div className="water-reminder">
          <div className="flex items-center">
            <Droplet className="h-5 w-5 text-blue-500 mr-2" />
            <span>Hora de beber água! Hidrate-se para manter o foco.</span>
          </div>
          <button 
            onClick={() => {
              setShowWaterReminder(false)
              ganharXP(2) // Ganhar XP por reconhecer a importância da hidratação
            }}
            className="absolute top-1 right-1 text-xs p-1"
            aria-label="Fechar lembrete"
          >
            ✕
          </button>
        </div>
      )}
    </MainLayout>
  )
}
