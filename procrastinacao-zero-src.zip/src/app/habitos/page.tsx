"use client"

import React, { useState, useEffect } from "react"
import { MainLayout } from "@/components/main-layout"
import { HabitTracker } from "@/components/habit-tracker"
import { BarChart, Droplet, Apple, Moon, Brain } from "lucide-react"

type HabitoRegistro = {
  data: string;
  agua: number;
  refeicoes: number;
  sono: number;
  estudos: number;
}

export default function Habitos() {
  const [registros, setRegistros] = useState<HabitoRegistro[]>([
    { 
      data: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      agua: 5, 
      refeicoes: 3, 
      sono: 6, 
      estudos: 2 
    },
    { 
      data: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
      agua: 6, 
      refeicoes: 4, 
      sono: 7, 
      estudos: 3 
    },
    { 
      data: new Date().toISOString().split('T')[0], 
      agua: 2, 
      refeicoes: 1, 
      sono: 0, 
      estudos: 1 
    }
  ])
  
  const [horasDormidas, setHorasDormidas] = useState(7)
  const [horasEstudo, setHorasEstudo] = useState(2)
  
  const atualizarRegistroHoje = (campo: keyof HabitoRegistro, valor: number) => {
    const hoje = new Date().toISOString().split('T')[0]
    
    setRegistros(prev => {
      const registroHoje = prev.find(r => r.data === hoje)
      
      if (registroHoje) {
        return prev.map(r => 
          r.data === hoje ? { ...r, [campo]: valor } : r
        )
      } else {
        return [
          ...prev,
          { 
            data: hoje, 
            agua: campo === 'agua' ? valor : 0, 
            refeicoes: campo === 'refeicoes' ? valor : 0, 
            sono: campo === 'sono' ? valor : 0, 
            estudos: campo === 'estudos' ? valor : 0 
          }
        ]
      }
    })
  }
  
  // Obter o registro de hoje ou criar um novo
  const getRegistroHoje = () => {
    const hoje = new Date().toISOString().split('T')[0]
    return registros.find(r => r.data === hoje) || { 
      data: hoje, 
      agua: 0, 
      refeicoes: 0, 
      sono: 0, 
      estudos: 0 
    }
  }
  
  const registroHoje = getRegistroHoje()
  
  // Calcular média dos últimos dias (excluindo hoje)
  const calcularMedia = (campo: keyof HabitoRegistro) => {
    const hoje = new Date().toISOString().split('T')[0]
    const registrosAnteriores = registros.filter(r => r.data !== hoje)
    
    if (registrosAnteriores.length === 0) return 0
    
    const soma = registrosAnteriores.reduce((acc, r) => acc + r[campo], 0)
    return soma / registrosAnteriores.length
  }
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Monitoramento de Hábitos</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Droplet className="h-5 w-5 text-blue-500 mr-2" />
              Hidratação
            </h2>
            
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Hoje</span>
                <span className="text-sm text-muted-foreground">{registroHoje.agua}/8 copos</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-bar-fill bg-blue-500" 
                  style={{ width: `${Math.min(100, (registroHoje.agua / 8) * 100)}%` }}
                ></div>
              </div>
              <div className="flex justify-between mt-2">
                <button 
                  onClick={() => atualizarRegistroHoje('agua', Math.max(0, registroHoje.agua - 1))}
                  className="text-xs px-2 py-1 rounded bg-secondary text-secondary-foreground"
                  disabled={registroHoje.agua <= 0}
                >
                  -
                </button>
                <button 
                  onClick={() => atualizarRegistroHoje('agua', Math.min(8, registroHoje.agua + 1))}
                  className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground"
                >
                  + Copo
                </button>
              </div>
            </div>
            
            <div className="text-sm">
              <div className="flex justify-between mb-1">
                <span>Média dos últimos dias:</span>
                <span className="font-medium">{calcularMedia('agua').toFixed(1)} copos</span>
              </div>
              <div className="text-xs text-muted-foreground">
                {calcularMedia('agua') < 6 
                  ? "Você precisa melhorar sua hidratação!" 
                  : "Boa hidratação! Continue assim."}
              </div>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Apple className="h-5 w-5 text-green-500 mr-2" />
              Alimentação
            </h2>
            
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Hoje</span>
                <span className="text-sm text-muted-foreground">{registroHoje.refeicoes}/5 refeições</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-bar-fill bg-green-500" 
                  style={{ width: `${Math.min(100, (registroHoje.refeicoes / 5) * 100)}%` }}
                ></div>
              </div>
              <div className="flex justify-between mt-2">
                <button 
                  onClick={() => atualizarRegistroHoje('refeicoes', Math.max(0, registroHoje.refeicoes - 1))}
                  className="text-xs px-2 py-1 rounded bg-secondary text-secondary-foreground"
                  disabled={registroHoje.refeicoes <= 0}
                >
                  -
                </button>
                <button 
                  onClick={() => atualizarRegistroHoje('refeicoes', Math.min(5, registroHoje.refeicoes + 1))}
                  className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground"
                >
                  + Refeição
                </button>
              </div>
            </div>
            
            <div className="text-sm">
              <div className="flex justify-between mb-1">
                <span>Média dos últimos dias:</span>
                <span className="font-medium">{calcularMedia('refeicoes').toFixed(1)} refeições</span>
              </div>
              <div className="text-xs text-muted-foreground">
                {calcularMedia('refeicoes') < 3 
                  ? "Tente fazer mais refeições saudáveis!" 
                  : "Boa alimentação! Continue assim."}
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Moon className="h-5 w-5 text-indigo-500 mr-2" />
              Sono
            </h2>
            
            <div className="mb-4">
              <label htmlFor="sono" className="block text-sm font-medium mb-2">
                Quantas horas você dormiu na noite passada?
              </label>
              <div className="flex items-center">
                <input
                  type="range"
                  id="sono"
                  min="0"
                  max="12"
                  step="0.5"
                  value={horasDormidas}
                  onChange={(e) => {
                    const valor = parseFloat(e.target.value)
                    setHorasDormidas(valor)
                    atualizarRegistroHoje('sono', valor)
                  }}
                  className="flex-1 mr-2"
                />
                <span className="text-lg font-medium w-12 text-center">{horasDormidas}h</span>
              </div>
            </div>
            
            <div className="p-3 rounded-md bg-indigo-50 dark:bg-indigo-900/30 text-sm">
              <p className="font-medium mb-1">Dica para melhorar o sono:</p>
              <p className="text-xs text-indigo-700 dark:text-indigo-300">
                Evite telas (celular, computador, TV) pelo menos 1 hora antes de dormir.
                A luz azul interfere na produção de melatonina, hormônio do sono.
              </p>
            </div>
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <Brain className="h-5 w-5 text-purple-500 mr-2" />
              Estudos
            </h2>
            
            <div className="mb-4">
              <label htmlFor="estudos" className="block text-sm font-medium mb-2">
                Quantas horas você estudou hoje?
              </label>
              <div className="flex items-center">
                <input
                  type="range"
                  id="estudos"
                  min="0"
                  max="10"
                  step="0.5"
                  value={horasEstudo}
                  onChange={(e) => {
                    const valor = parseFloat(e.target.value)
                    setHorasEstudo(valor)
                    atualizarRegistroHoje('estudos', valor)
                  }}
                  className="flex-1 mr-2"
                />
                <span className="text-lg font-medium w-12 text-center">{horasEstudo}h</span>
              </div>
            </div>
            
            <div className="p-3 rounded-md bg-purple-50 dark:bg-purple-900/30 text-sm">
              <p className="font-medium mb-1">Dica para estudos eficientes:</p>
              <p className="text-xs text-purple-700 dark:text-purple-300">
                Estudar por períodos curtos e intensos (25 minutos) com pequenas pausas (5 minutos)
                é mais eficiente que longas sessões sem intervalos. Use o método Pomodoro!
              </p>
            </div>
          </div>
        </div>
        
        <div className="habit-card mb-8">
          <h2 className="text-lg font-medium mb-4 flex items-center">
            <BarChart className="h-5 w-5 text-primary mr-2" />
            Histórico de Hábitos
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-3">Data</th>
                  <th className="text-center py-2 px-3">Água</th>
                  <th className="text-center py-2 px-3">Refeições</th>
                  <th className="text-center py-2 px-3">Sono</th>
                  <th className="text-center py-2 px-3">Estudos</th>
                </tr>
              </thead>
              <tbody>
                {registros.sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime()).map(registro => (
                  <tr key={registro.data} className="border-b">
                    <td className="py-2 px-3">
                      {new Date(registro.data).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="text-center py-2 px-3">
                      <span className={registro.agua >= 6 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}>
                        {registro.agua} copos
                      </span>
                    </td>
                    <td className="text-center py-2 px-3">
                      <span className={registro.refeicoes >= 3 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}>
                        {registro.refeicoes} ref.
                      </span>
                    </td>
                    <td className="text-center py-2 px-3">
                      <span className={registro.sono >= 7 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}>
                        {registro.sono}h
                      </span>
                    </td>
                    <td className="text-center py-2 px-3">
                      <span className={registro.estudos >= 2 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}>
                        {registro.estudos}h
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
