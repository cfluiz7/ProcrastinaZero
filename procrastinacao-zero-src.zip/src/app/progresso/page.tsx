"use client"

import React, { useState, useEffect } from "react"
import { MainLayout } from "@/components/main-layout"
import { ProgressSystem } from "@/components/progress-system"
import { Trophy, Star, Flame, Award, Target, TrendingUp } from "lucide-react"

type Conquista = {
  id: number;
  nome: string;
  descricao: string;
  obtida: boolean;
  data?: string;
  icone: string;
}

type Nivel = {
  nivel: number;
  nome: string;
  xpNecessario: number;
  beneficios: string[];
}

export default function Progresso() {
  const [nivel, setNivel] = useState(1)
  const [xp, setXp] = useState(30)
  const [streak, setStreak] = useState(3)
  
  const [conquistas, setConquistas] = useState<Conquista[]>([
    { 
      id: 1, 
      nome: "Primeiro Passo", 
      descricao: "Completou seu primeiro dia no sistema", 
      obtida: true, 
      data: "23/04/2025",
      icone: "trophy"
    },
    { 
      id: 2, 
      nome: "Sequência Inicial", 
      descricao: "Manteve 3 dias seguidos de atividade", 
      obtida: true, 
      data: "25/04/2025",
      icone: "flame"
    },
    { 
      id: 3, 
      nome: "Hidratação Consciente", 
      descricao: "Bebeu 8 copos de água em um único dia", 
      obtida: false,
      icone: "droplet" 
    },
    { 
      id: 4, 
      nome: "Mestre do Foco", 
      descricao: "Completou 5 ciclos Pomodoro em um dia", 
      obtida: false,
      icone: "target" 
    },
    { 
      id: 5, 
      nome: "Dorminhoco Saudável", 
      descricao: "Dormiu pelo menos 8 horas por 5 dias seguidos", 
      obtida: false,
      icone: "moon" 
    },
    { 
      id: 6, 
      nome: "Alimentação Equilibrada", 
      descricao: "Registrou 5 refeições saudáveis em um dia", 
      obtida: false,
      icone: "apple" 
    },
    { 
      id: 7, 
      nome: "Estudante Dedicado", 
      descricao: "Estudou pelo menos 4 horas em um único dia", 
      obtida: false,
      icone: "book-open" 
    },
    { 
      id: 8, 
      nome: "Organizador Master", 
      descricao: "Criou e completou 10 tarefas no cronograma", 
      obtida: false,
      icone: "check-square" 
    },
  ])
  
  const niveis: Nivel[] = [
    {
      nivel: 1,
      nome: "Iniciante",
      xpNecessario: 0,
      beneficios: ["Acesso às funcionalidades básicas"]
    },
    {
      nivel: 2,
      nome: "Aprendiz",
      xpNecessario: 100,
      beneficios: ["Desbloqueio de temas personalizados", "Novas dicas de produtividade"]
    },
    {
      nivel: 3,
      nome: "Estudante Dedicado",
      xpNecessario: 250,
      beneficios: ["Estatísticas avançadas", "Mais opções de personalização"]
    },
    {
      nivel: 4,
      nome: "Mestre do Foco",
      xpNecessario: 500,
      beneficios: ["Ferramentas avançadas de estudo", "Novos desafios diários"]
    },
    {
      nivel: 5,
      nome: "Produtividade Suprema",
      xpNecessario: 1000,
      beneficios: ["Acesso a todas as funcionalidades", "Reconhecimento especial"]
    }
  ]
  
  const nivelAtual = niveis.find(n => n.nivel === nivel) || niveis[0]
  const proximoNivel = niveis.find(n => n.nivel === nivel + 1)
  
  const xpParaProximoNivel = proximoNivel ? proximoNivel.xpNecessario - nivelAtual.xpNecessario : 0
  const xpAtual = xp - nivelAtual.xpNecessario
  const progresso = proximoNivel ? (xpAtual / xpParaProximoNivel) * 100 : 100
  
  // Simulação de ganho de XP
  const ganharXP = (quantidade: number) => {
    let novoXP = xp + quantidade
    let novoNivel = nivel
    
    // Verificar se subiu de nível
    while (proximoNivel && novoXP >= proximoNivel.xpNecessario) {
      novoNivel++
    }
    
    setXp(novoXP)
    if (novoNivel !== nivel) {
      setNivel(novoNivel)
    }
  }
  
  // Simulação de conquista de medalha
  const conquistarMedalha = (id: number) => {
    setConquistas(prev => 
      prev.map(c => 
        c.id === id 
          ? { ...c, obtida: true, data: new Date().toLocaleDateString('pt-BR') } 
          : c
      )
    )
    
    // Ganhar XP pela conquista
    ganharXP(25)
  }
  
  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Seu Progresso</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="habit-card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium flex items-center">
                <Trophy className="h-5 w-5 text-amber-500 mr-2" />
                Nível e Experiência
              </h2>
              
              <div className="level-indicator">
                <span className="px-2 py-1 rounded-full bg-primary/10 text-primary">
                  Nível {nivel}
                </span>
              </div>
            </div>
            
            <div className="text-center mb-4">
              <h3 className="text-xl font-bold text-primary">{nivelAtual.nome}</h3>
            </div>
            
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm">XP para o próximo nível</span>
                <span className="text-sm text-muted-foreground">
                  {proximoNivel ? `${xpAtual}/${xpParaProximoNivel}` : "Nível máximo"}
                </span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-bar-fill bg-primary" 
                  style={{ width: `${progresso}%` }}
                ></div>
              </div>
            </div>
            
            <div className="flex items-center mb-4">
              <div className="streak-counter">
                <Flame className="h-4 w-4 text-amber-500" />
                <span>{streak} dias seguidos</span>
              </div>
            </div>
            
            <div className="p-3 rounded-md bg-amber-50 dark:bg-amber-900/30 mb-4">
              <h4 className="font-medium text-sm mb-1">Benefícios do seu nível:</h4>
              <ul className="text-xs text-amber-700 dark:text-amber-300 space-y-1">
                {nivelAtual.beneficios.map((beneficio, index) => (
                  <li key={index}>• {beneficio}</li>
                ))}
              </ul>
            </div>
            
            {proximoNivel && (
              <div className="text-center text-sm">
                <p className="text-muted-foreground">
                  Próximo nível: <span className="font-medium">{proximoNivel.nome}</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  Faltam {proximoNivel.xpNecessario - xp} pontos de experiência
                </p>
              </div>
            )}
          </div>
          
          <div className="habit-card">
            <h2 className="text-lg font-medium mb-4 flex items-center">
              <TrendingUp className="h-5 w-5 text-primary mr-2" />
              Como Ganhar XP
            </h2>
            
            <div className="space-y-3">
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Completar tarefas</span>
                  <span className="text-sm text-primary">+10 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Ciclo Pomodoro</span>
                  <span className="text-sm text-primary">+5 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Beber 8 copos de água</span>
                  <span className="text-sm text-primary">+15 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">5 refeições saudáveis</span>
                  <span className="text-sm text-primary">+15 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Dormir 8 horas</span>
                  <span className="text-sm text-primary">+10 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Conquistar medalha</span>
                  <span className="text-sm text-primary">+25 XP</span>
                </div>
              </div>
              
              <div className="p-2 rounded-md bg-card border border-border">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Manter sequência diária</span>
                  <span className="text-sm text-primary">+5 XP por dia</span>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <button
                onClick={() => ganharXP(10)}
                className="w-full py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Simular ganho de XP (+10)
              </button>
            </div>
          </div>
        </div>
        
        <div className="habit-card mb-8">
          <h2 className="text-lg font-medium mb-6 flex items-center">
            <Award className="h-5 w-5 text-amber-500 mr-2" />
            Suas Conquistas
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {conquistas.map(conquista => {
              let Icone
              switch (conquista.icone) {
                case "trophy": Icone = Trophy; break;
                case "flame": Icone = Flame; break;
                case "target": Icone = Target; break;
                default: Icone = Star;
              }
              
              return (
                <div 
                  key={conquista.id}
                  className={`p-4 rounded-lg border ${
                    conquista.obtida 
                      ? "bg-amber-50 border-amber-200 dark:bg-amber-900/30 dark:border-amber-800" 
                      : "bg-gray-50 border-gray-200 dark:bg-gray-800/50 dark:border-gray-700"
                  }`}
                >
                  <div className="flex items-center mb-2">
                    <div className={`p-2 rounded-full ${
                      conquista.obtida 
                        ? "bg-amber-100 text-amber-600 dark:bg-amber-800 dark:text-amber-200" 
                        : "bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400"
                    }`}>
                      <Icone className="h-5 w-5" />
                    </div>
                    <h3 className="ml-2 font-medium">{conquista.nome}</h3>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">
                    {conquista.descricao}
                  </p>
                  
                  {conquista.obtida ? (
                    <div className="text-xs text-amber-600 dark:text-amber-400">
                      Conquistado em {conquista.data}
                    </div>
                  ) : (
                    <button
                      onClick={() => conquistarMedalha(conquista.id)}
                      className="text-xs px-2 py-1 rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    >
                      Simular conquista
                    </button>
                  )}
                </div>
              )
            })}
          </div>
        </div>
        
        <div className="habit-card mb-8">
          <h2 className="text-lg font-medium mb-4 flex items-center">
            <Target className="h-5 w-5 text-primary mr-2" />
            Dicas Motivacionais
          </h2>
          
          <div className="space-y-4">
            <div className="p-4 rounded-md bg-primary/5 border border-primary/20">
              <p className="text-center italic">
                "A disciplina é a ponte entre metas e realizações."
              </p>
              <p className="text-center text-sm text-muted-foreground mt-1">
                — Jim Rohn
              </p>
            </div>
            
            <div className="p-4 rounded-md bg-primary/5 border border-primary/20">
              <p className="text-center italic">
                "Não espere por circunstâncias ideais. Nunca serão ideais. Comece onde você está."
              </p>
              <p className="text-center text-sm text-muted-foreground mt-1">
                — Napoleon Hill
              </p>
            </div>
            
            <div className="p-4 rounded-md bg-primary/5 border border-primary/20">
              <p className="text-center italic">
                "O segredo para seguir em frente é começar."
              </p>
              <p className="text-center text-sm text-muted-foreground mt-1">
                — Mark Twain
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
